"use client"
import RotatingSphere from "./components/RotatingSphere";

const Home: React.FC = () => {
  return (
    <main className="bg-black text-white">
      <RotatingSphere />
    </main>
  );
};

export default Home;
